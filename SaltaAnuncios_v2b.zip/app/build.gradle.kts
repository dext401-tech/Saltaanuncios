plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mc.saltaanuncios"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mc.saltaanuncios"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    // Firma fija: así cada versión nueva se instala encima sin desinstalar
    signingConfigs {
        create("mc") {
            storeFile = file("../mc.keystore")
            storePassword = "saltaanuncios"
            keyAlias = "mc"
            keyPassword = "saltaanuncios"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("mc")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
