package com.mc.dnsmc;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final String ADB_CMD =
            "adb shell pm grant com.mc.dnsmc android.permission.WRITE_SECURE_SETTINGS";

    private TextView txtPermiso, txtEstado;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(20);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(pad, pad * 2, pad, pad);

        TextView titulo = new TextView(this);
        titulo.setText("DNS MC");
        titulo.setTextSize(28);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        l.addView(titulo);

        txtPermiso = new TextView(this);
        txtPermiso.setTextSize(16);
        txtPermiso.setPadding(0, dp(12), 0, dp(4));
        l.addView(txtPermiso);

        TextView cmd = new TextView(this);
        cmd.setText(ADB_CMD);
        cmd.setTypeface(Typeface.MONOSPACE);
        cmd.setTextIsSelectable(true);
        cmd.setPadding(0, dp(4), 0, dp(4));
        l.addView(cmd);

        Button copiar = new Button(this);
        copiar.setText("Copiar comando ADB");
        copiar.setOnClickListener(x -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            cm.setPrimaryClip(ClipData.newPlainText("adb", ADB_CMD));
            Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show();
        });
        l.addView(copiar);

        txtEstado = new TextView(this);
        txtEstado.setTextSize(22);
        txtEstado.setTypeface(Typeface.DEFAULT_BOLD);
        txtEstado.setGravity(Gravity.CENTER);
        txtEstado.setPadding(0, dp(28), 0, dp(12));
        l.addView(txtEstado);

        l.addView(boton("Apagado", DnsHelper.OFF));
        l.addView(boton("AdGuard (bloquea anuncios)", DnsHelper.ADGUARD));
        l.addView(boton("Google", DnsHelper.GOOGLE));

        TextView ayuda = new TextView(this);
        ayuda.setText("\nAgrega el widget \"DNS MC\" a tu pantalla de inicio. "
                + "Cada toque cambia: Apagado → AdGuard → Google → Apagado.");
        l.addView(ayuda);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }

    private Button boton(String texto, int estado) {
        Button bt = new Button(this);
        bt.setText(texto);
        bt.setOnClickListener(x -> {
            if (!DnsHelper.hasPermission(this)) {
                Toast.makeText(this, "Primero da el permiso por ADB", Toast.LENGTH_LONG).show();
                return;
            }
            DnsHelper.set(this, estado);
            refrescar();
            DnsWidget.refreshAll(this);
        });
        return bt;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refrescar();
        DnsWidget.refreshAll(this);
    }

    private void refrescar() {
        boolean ok = DnsHelper.hasPermission(this);
        txtPermiso.setText(ok ? "✅ Permiso concedido. Ya puedes usar el widget."
                              : "⚠️ Falta permiso. Conecta el cel a la laptop y ejecuta:");
        txtPermiso.setTextColor(ok ? Color.rgb(76, 175, 80) : Color.rgb(255, 152, 0));
        txtEstado.setText("DNS actual: " + DnsHelper.name(DnsHelper.current(this)));
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
