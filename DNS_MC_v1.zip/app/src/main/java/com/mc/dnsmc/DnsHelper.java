package com.mc.dnsmc;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;

/** Lee y cambia el DNS privado del sistema. No usa servicios ni nada en segundo plano. */
public final class DnsHelper {

    public static final int OFF = 0, ADGUARD = 1, GOOGLE = 2;

    static final String ADGUARD_HOST = "dns.adguard-dns.com";
    static final String GOOGLE_HOST = "dns.google";

    private static final String KEY_MODE = "private_dns_mode";
    private static final String KEY_HOST = "private_dns_specifier";

    private DnsHelper() {}

    public static boolean hasPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Estado real del sistema (por si lo cambiaste desde Ajustes). */
    public static int current(Context c) {
        String mode = Settings.Global.getString(c.getContentResolver(), KEY_MODE);
        String host = Settings.Global.getString(c.getContentResolver(), KEY_HOST);
        if ("hostname".equals(mode) && host != null) {
            if (host.equalsIgnoreCase(ADGUARD_HOST)) return ADGUARD;
            if (host.equalsIgnoreCase(GOOGLE_HOST)) return GOOGLE;
            return -1; // otro DNS puesto a mano
        }
        if ("off".equals(mode)) return OFF;
        return -2; // automático
    }

    public static boolean set(Context c, int state) {
        try {
            if (state == OFF) {
                Settings.Global.putString(c.getContentResolver(), KEY_MODE, "off");
            } else {
                String host = state == ADGUARD ? ADGUARD_HOST : GOOGLE_HOST;
                Settings.Global.putString(c.getContentResolver(), KEY_HOST, host);
                Settings.Global.putString(c.getContentResolver(), KEY_MODE, "hostname");
            }
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    /** Apagado -> AdGuard -> Google -> Apagado */
    public static int next(int cur) {
        if (cur == ADGUARD) return GOOGLE;
        if (cur == GOOGLE) return OFF;
        if (cur == OFF) return ADGUARD;
        return ADGUARD; // automático u otro -> AdGuard
    }

    public static String name(int state) {
        switch (state) {
            case OFF: return "Apagado";
            case ADGUARD: return "AdGuard";
            case GOOGLE: return "Google";
            case -1: return "Otro";
            default: return "Automático";
        }
    }
}
