package com.mc.dnsmc;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.Toast;

/** Widget de un botón. Solo se despierta cuando lo tocas: cero consumo en reposo. */
public class DnsWidget extends AppWidgetProvider {

    private static final String ACTION_TOGGLE = "com.mc.dnsmc.TOGGLE";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        refreshAll(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (!ACTION_TOGGLE.equals(i.getAction())) return;

        if (!DnsHelper.hasPermission(c)) {
            Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(open);
            Toast.makeText(c, "DNS MC: falta dar el permiso por ADB", Toast.LENGTH_LONG).show();
            return;
        }
        int nuevo = DnsHelper.next(DnsHelper.current(c));
        if (DnsHelper.set(c, nuevo)) {
            Toast.makeText(c, "DNS: " + DnsHelper.name(nuevo), Toast.LENGTH_SHORT).show();
        }
        refreshAll(c);
    }

    public static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, DnsWidget.class));
        if (ids.length == 0) return;

        int st = DnsHelper.current(c);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_dns);
        v.setTextViewText(R.id.txtEstado, DnsHelper.name(st));
        int bg = st == DnsHelper.ADGUARD ? R.drawable.bg_adguard
               : st == DnsHelper.GOOGLE ? R.drawable.bg_google
               : R.drawable.bg_off;
        v.setInt(R.id.root, "setBackgroundResource", bg);

        Intent t = new Intent(c, DnsWidget.class).setAction(ACTION_TOGGLE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, t,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.root, pi);

        m.updateAppWidget(ids, v);
    }
}
