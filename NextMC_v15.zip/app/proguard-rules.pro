# Next MC - reglas para el optimizador
-keep class com.mc.saltaanuncios.** { *; }
