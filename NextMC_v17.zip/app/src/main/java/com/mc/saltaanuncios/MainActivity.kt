package com.mc.saltaanuncios

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var txtEstado: TextView
    private lateinit var txtRegistro: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnDiag: Button
    private lateinit var btnOscurecer: Button
    private lateinit var btnSilenciar: Button
    private lateinit var btnIgnorar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtEstado = findViewById(R.id.txtEstado)
        txtRegistro = findViewById(R.id.txtRegistro)
        scroll = findViewById(R.id.scrollRegistro)
        btnDiag = findViewById(R.id.btnDiagnostico)
        btnOscurecer = findViewById(R.id.btnOscurecer)
        btnSilenciar = findViewById(R.id.btnSilenciar)
        btnIgnorar = findViewById(R.id.btnIgnorar)
        btnIgnorar.setOnClickListener {
            val app = Prefs.ultimaApp(this)
            if (app.isEmpty()) {
                Toast.makeText(this, "Todavía no ha detectado anuncios en ninguna app", Toast.LENGTH_LONG).show()
            } else {
                Prefs.cambiarIgnorada(this, app)
                val ahora = if (Prefs.ignorada(this, app)) "Ignorando" else "Ya no ignoro"
                AdLog.agregar(this, "$ahora la app: $app")
                Toast.makeText(this, "$ahora: $app", Toast.LENGTH_LONG).show()
            }
            actualizar()
        }

        btnOscurecer.setOnClickListener {
            Prefs.setOscurecer(this, !Prefs.oscurecer(this))
            actualizar()
        }
        btnSilenciar.setOnClickListener {
            Prefs.setSilenciar(this, !Prefs.silenciar(this))
            actualizar()
        }

        findViewById<Button>(R.id.btnAccesibilidad).setOnClickListener { abrirAccesibilidad() }

        btnDiag.setOnClickListener {
            Prefs.setDiagnostico(this, !Prefs.diagnostico(this))
            actualizar()
        }

        findViewById<Button>(R.id.btnActualizar).setOnClickListener { actualizar() }

        findViewById<Button>(R.id.btnBorrar).setOnClickListener {
            AdLog.borrar(this)
            actualizar()
        }

        // Que el control empiece en el primer botón
        if (servicioActivo()) btnOscurecer.requestFocus() else findViewById<Button>(R.id.btnAccesibilidad).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        actualizar()
    }

    private fun actualizar() {
        // El botón de Accesibilidad solo se ve si el servicio está apagado
        val activo = servicioActivo()
        val btnAcc = findViewById<Button>(R.id.btnAccesibilidad)
        btnAcc.visibility = if (activo) View.GONE else View.VISIBLE
        if (activo && btnAcc.isFocused) btnOscurecer.requestFocus()

        txtEstado.text = if (servicioActivo())
            "✅ Servicio ACTIVO: ya está saltando anuncios"
        else
            "❌ Servicio APAGADO: Ajustes > Preferencias del dispositivo > Accesibilidad > Next MC"

        btnDiag.text = if (Prefs.diagnostico(this)) "Registro: SÍ" else "Registro: NO"

        btnOscurecer.text = if (Prefs.oscurecer(this)) "Oscurecer: SÍ" else "Oscurecer: NO"
        btnSilenciar.text = if (Prefs.silenciar(this)) "Silenciar: SÍ" else "Silenciar: NO"

        val app = Prefs.ultimaApp(this)
        val corto = app.split('.').filter { it != "com" && it != "app" && it != "tv" && it != "android" }
            .firstOrNull() ?: app
        btnIgnorar.text = when {
            app.isEmpty() -> "Ignorar app"
            Prefs.ignorada(this, app) -> "Dejar de ignorar: $corto"
            else -> "Ignorar: $corto"
        }

        val ign = Prefs.ignoradas(this)
        val lineaIgn = if (ign.isEmpty()) "" else "Apps ignoradas: " + ign.joinToString(", ") + "\n\n"
        val vacio = if (Prefs.diagnostico(this)) "(Sin registros todavía)" else "(Registro apagado: no se anota nada)"
        txtRegistro.text = lineaIgn + AdLog.leer(this).ifBlank { vacio }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** Abre Accesibilidad probando varias rutas (en Android TV la normal a veces no funciona). */
    private fun abrirAccesibilidad() {
        val esTV = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        val tv = "com.android.tv.settings"
        val rutasTV = listOf(
            // Android TV más viejo (como algunas Shield)
            Intent().setClassName(tv, "$tv.system.AccessibilityActivity"),
            // Android TV más nuevo
            Intent().setClassName(tv, "$tv.accessibility.AccessibilityActivity"),
            Intent().setClassName(tv, "$tv.accessibility.AccessibilitySettingsActivity"),
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).setPackage(tv),
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        )
        val rutasNormales = listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        val rutas = (if (esTV) rutasTV else rutasNormales) + listOf(
            Intent().setClassName("com.android.tv.settings", "com.android.tv.settings.MainSettings"),
            Intent(Settings.ACTION_SETTINGS)
        )

        // Solo abrir una ruta que de verdad exista (si no, Android dice "no hay app que pueda abrir")
        for (intent in rutas) {
            val ri = try {
                packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            } catch (e: Exception) {
                null
            } ?: continue
            val nombre = ri.activityInfo?.name ?: continue
            if ("Resolver" in nombre || "Chooser" in nombre || ri.activityInfo?.exported != true) continue
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                AdLog.agregar(this, "Abrí ajustes con: ${nombre.substringAfterLast('.')}")
                if (intent.action == Settings.ACTION_SETTINGS || "MainSettings" in nombre) {
                    Toast.makeText(
                        this,
                        "Ve a Preferencias del dispositivo > Accesibilidad > Next MC",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return
            } catch (e: Exception) {
            }
        }
        AdLog.agregar(this, "No encontré la pantalla de Accesibilidad en este aparato")
        Toast.makeText(
            this,
            "Ábrelo a mano: Ajustes > Preferencias del dispositivo > Accesibilidad > Next MC",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun servicioActivo(): Boolean {
        val habilitados = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, SaltaAnunciosService::class.java)
        val nombres = setOf(cn.flattenToString(), cn.flattenToShortString())
        return habilitados.split(':').any { s -> nombres.any { it.equals(s, ignoreCase = true) } }
    }
}
