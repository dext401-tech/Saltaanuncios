package com.mc.saltaanuncios

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var txtEstado: TextView
    private lateinit var txtRegistro: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnDiag: Button
    private lateinit var btnOscurecer: Button
    private lateinit var btnSilenciar: Button
    private lateinit var btnYoutube: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtEstado = findViewById(R.id.txtEstado)
        txtRegistro = findViewById(R.id.txtRegistro)
        scroll = findViewById(R.id.scrollRegistro)
        btnDiag = findViewById(R.id.btnDiagnostico)
        btnOscurecer = findViewById(R.id.btnOscurecer)
        btnSilenciar = findViewById(R.id.btnSilenciar)
        btnYoutube = findViewById(R.id.btnYoutube)
        btnYoutube.setOnClickListener {
            Prefs.setModoYoutube(this, !Prefs.modoYoutube(this))
            actualizar()
        }

        btnOscurecer.setOnClickListener {
            Prefs.setOscurecer(this, !Prefs.oscurecer(this))
            actualizar()
        }
        btnSilenciar.setOnClickListener {
            Prefs.setSilenciar(this, !Prefs.silenciar(this))
            actualizar()
        }

        findViewById<Button>(R.id.btnAccesibilidad).setOnClickListener { abrirAccesibilidad() }

        btnDiag.setOnClickListener {
            Prefs.setDiagnostico(this, !Prefs.diagnostico(this))
            actualizar()
        }

        findViewById<Button>(R.id.btnActualizar).setOnClickListener { actualizar() }

        findViewById<Button>(R.id.btnBorrar).setOnClickListener {
            AdLog.borrar(this)
            actualizar()
        }

        // Que el control empiece en el primer botón
        findViewById<Button>(R.id.btnAccesibilidad).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        actualizar()
    }

    private fun actualizar() {
        txtEstado.text = if (servicioActivo())
            "✅ Servicio ACTIVO: ya está saltando anuncios"
        else
            "❌ Servicio APAGADO: Ajustes > Preferencias del dispositivo > Accesibilidad > Salta Anuncios MC"

        btnDiag.text = if (Prefs.diagnostico(this))
            "Diagnóstico: ENCENDIDO"
        else
            "Diagnóstico: APAGADO"

        btnOscurecer.text = if (Prefs.oscurecer(this)) "Oscurecer: SÍ" else "Oscurecer: NO"
        btnSilenciar.text = if (Prefs.silenciar(this)) "Silenciar: SÍ" else "Silenciar: NO"
        btnYoutube.text = if (Prefs.modoYoutube(this)) "Modo YouTube: SÍ" else "Modo YouTube: NO"

        txtRegistro.text = AdLog.leer(this).ifBlank { "(Sin registros todavía)" }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** Abre Accesibilidad probando varias rutas (en Android TV la normal a veces no funciona). */
    private fun abrirAccesibilidad() {
        val esTV = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        val rutasTV = listOf(
            Intent().setClassName("com.android.tv.settings", "com.android.tv.settings.accessibility.AccessibilityActivity"),
            Intent().setClassName("com.android.tv.settings", "com.android.tv.settings.accessibility.AccessibilitySettingsActivity"),
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        )
        val rutasNormales = listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        val rutas = (if (esTV) rutasTV else rutasNormales) + listOf(
            Intent().setClassName("com.android.tv.settings", "com.android.tv.settings.MainSettings"),
            Intent(Settings.ACTION_SETTINGS)
        )

        // Solo abrir una ruta que de verdad exista (si no, Android dice "no hay app que pueda abrir")
        for (intent in rutas) {
            val ri = try {
                packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            } catch (e: Exception) {
                null
            } ?: continue
            val nombre = ri.activityInfo?.name ?: continue
            if ("Resolver" in nombre || ri.activityInfo?.exported != true) continue
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                AdLog.agregar(this, "Abrí ajustes con: ${nombre.substringAfterLast('.')}")
                if (intent.action == Settings.ACTION_SETTINGS || "MainSettings" in nombre) {
                    Toast.makeText(
                        this,
                        "Ve a Preferencias del dispositivo > Accesibilidad > Salta Anuncios MC",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return
            } catch (e: Exception) {
            }
        }
        AdLog.agregar(this, "No encontré la pantalla de Accesibilidad en este aparato")
        Toast.makeText(
            this,
            "Ábrelo a mano: Ajustes > Preferencias del dispositivo > Accesibilidad > Salta Anuncios MC",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun servicioActivo(): Boolean {
        val habilitados = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, SaltaAnunciosService::class.java)
        val nombres = setOf(cn.flattenToString(), cn.flattenToShortString())
        return habilitados.split(':').any { s -> nombres.any { it.equals(s, ignoreCase = true) } }
    }
}
