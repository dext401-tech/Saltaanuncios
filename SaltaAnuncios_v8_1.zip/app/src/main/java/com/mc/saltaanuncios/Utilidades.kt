package com.mc.saltaanuncios

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private const val ARCHIVO = "ajustes"

    fun diagnostico(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("diagnostico", false)

    fun setDiagnostico(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("diagnostico", valor).apply()
    }

    fun oscurecer(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("oscurecer", true)

    fun setOscurecer(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("oscurecer", valor).apply()
    }

    fun modoYoutube(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("modoYoutube", true)

    fun setModoYoutube(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("modoYoutube", valor).apply()
    }

    fun silenciar(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("silenciar", true)

    fun setSilenciar(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("silenciar", valor).apply()
    }
}

/** Registro sencillo en un archivo (se ve dentro de la app, sin PC). */
object AdLog {
    private const val ARCHIVO = "registro.txt"
    private const val MAX_LINEAS = 400
    private val formato = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun agregar(c: Context, mensaje: String) {
        try {
            val f = File(c.filesDir, ARCHIVO)
            val lineas = if (f.exists()) f.readLines().toMutableList() else mutableListOf()
            val hora = formato.format(Date())
            mensaje.lines().forEachIndexed { i, l -> lineas.add(if (i == 0) "$hora  $l" else l) }
            val recorte = if (lineas.size > MAX_LINEAS) lineas.takeLast(MAX_LINEAS) else lineas
            f.writeText(recorte.joinToString("\n"))
        } catch (e: Exception) {
        }
    }

    fun leer(c: Context): String {
        val f = File(c.filesDir, ARCHIVO)
        return if (f.exists()) f.readText() else ""
    }

    fun borrar(c: Context) {
        File(c.filesDir, ARCHIVO).delete()
    }
}
