package com.mc.saltaanuncios

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private const val ARCHIVO = "ajustes"

    fun diagnostico(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("diagnostico", false)

    fun setDiagnostico(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("diagnostico", valor).apply()
    }

    fun oscurecer(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("oscurecer", true)

    fun setOscurecer(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("oscurecer", valor).apply()
    }

    fun ignorada(c: Context, pkg: String): Boolean =
        pkg in (c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getStringSet("ignoradas", emptySet()) ?: emptySet())

    fun cambiarIgnorada(c: Context, pkg: String) {
        val sp = c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)
        val actual = (sp.getStringSet("ignoradas", emptySet()) ?: emptySet()).toMutableSet()
        if (pkg in actual) actual.remove(pkg) else actual.add(pkg)
        sp.edit().putStringSet("ignoradas", actual).apply()
    }

    fun ignoradas(c: Context): Set<String> =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getStringSet("ignoradas", emptySet()) ?: emptySet()

    fun ultimaApp(c: Context): String =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getString("ultimaApp", "") ?: ""

    fun setUltimaApp(c: Context, pkg: String) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putString("ultimaApp", pkg).apply()
    }

    fun modoYoutube(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("modoYoutube", true)

    fun setModoYoutube(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("modoYoutube", valor).apply()
    }

    fun silenciar(c: Context): Boolean =
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("silenciar", true)

    fun setSilenciar(c: Context, valor: Boolean) {
        c.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("silenciar", valor).apply()
    }
}

/** Registro sencillo en un archivo. Solo agrega al final; si crece mucho, se recorta. */
object AdLog {
    private const val ARCHIVO = "registro.txt"
    private const val MAX_BYTES = 48_000L
    private val formato = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun agregar(c: Context, mensaje: String) {
        try {
            val f = File(c.filesDir, ARCHIVO)
            val hora = formato.format(Date())
            val texto = mensaje.lines().mapIndexed { i, l -> if (i == 0) "$hora  $l" else l }.joinToString("\n")
            f.appendText(texto + "\n")
            if (f.length() > MAX_BYTES) {
                // Conservar solo la mitad más reciente
                val todo = f.readText()
                val corte = todo.indexOf('\n', todo.length / 2)
                f.writeText(if (corte > 0) todo.substring(corte + 1) else "")
            }
        } catch (e: Exception) {
        }
    }

    fun leer(c: Context): String {
        val f = File(c.filesDir, ARCHIVO)
        return if (f.exists()) f.readText().trimEnd() else ""
    }

    fun borrar(c: Context) {
        File(c.filesDir, ARCHIVO).delete()
    }
}
