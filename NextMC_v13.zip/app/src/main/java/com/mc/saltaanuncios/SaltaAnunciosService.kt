package com.mc.saltaanuncios

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Next MC - versión 13 (antes Salta Anuncios MC / Next MC)
 * NO bloquea anuncios. Cuando la app ya ofrece "Omitir", "Saltar", "Skip"
 * o la X para cerrar, este servicio la presiona por ti.
 * v2: reconoce anuncios de pantalla completa de empresas de anuncios
 * (Mintegral/mbridge, AppLovin, Unity, AdMob, etc.) y su X sin texto.
 * v3: oscurece la pantalla y silencia mientras dura el anuncio.
 * v4: anuncios hechos como página web (Vungle/Liftoff, etc.): alterna
 *     "toque" simulado y clic, y reintenta hasta que la X funcione.
 * v12: sin lo de YouTube (se usa TizenTube): más ligera.
 * v13: detección instantánea por nombre de pantalla, logo en la capa, nombre Next MC.
 */
class SaltaAnunciosService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var escaneoPendiente = false
    private var ultimoClic = 0L
    private var ultimaEtiqueta = ""
    private var intentosMismo = 0
    private var reintentos = 0
    private var ultimoDiagnostico = 0L
    private var ultimaHuellaDiagnostico = 0

    // Pantalla (actividad) actual
    private var actividadActual = ""
    private var inicioActividad = 0L
    private var backsEnAnuncio = 0
    private var ultimoBack = 0L

    private val lanzadoresYAjustes = setOf(
        "com.android.tv.settings", "com.android.settings",
        "com.google.android.tvlauncher", "com.google.android.apps.tv.launcherx",
        "com.google.android.leanbacklauncher"
    )
    // Modo anuncio (oscurecer + silenciar)
    private val capas = mutableListOf<View>()
    private var textoCapa: TextView? = null
    private var inicioCapa = 0L
    private val formatoHora = java.text.SimpleDateFormat("h:mm a", java.util.Locale("es", "MX"))
    private val relojCapa = object : Runnable {
        override fun run() {
            val t = textoCapa ?: return
            val seg = (SystemClock.elapsedRealtime() - inicioCapa) / 1000
            t.text = "🕒 " + formatoHora.format(java.util.Date()) +
                    "\nAnuncio en curso · " + seg + " s" +
                    "\nLo quito en cuanto salga la X"
            handler.postDelayed(this, 1000)
        }
    }
    private var silenciadoPorMi = false
    private var enModoAnuncio = false
    private var ultimoAnuncioVisto = 0L
    private val revisarFin = Runnable {
        reintentos = 0
        programarEscaneo(0)
    }
    private val regexAnuncioEnCurso = Regex("""(anuncio|patrocinado|sponsored|\bad)\s*[·•:]?\s*\d""")

    // Apps donde nunca hace nada
    private val excluidos = setOf(
        "com.mc.saltaanuncios",
        "com.android.tv.settings",
        "com.android.settings",
        "com.android.systemui",
        "com.google.android.tvlauncher",
        "com.google.android.apps.tv.launcherx",
        "com.google.android.leanbacklauncher"
    )

    // Botones que SIEMPRE son de anuncio
    private val omitirSeguros = setOf(
        "omitir anuncio", "omitir anuncios", "omitir publicidad",
        "saltar anuncio", "saltar anuncios", "saltar publicidad",
        "skip ad", "skip ads", "skip advertisement"
    )
    // Botones cortos: solo con señales de anuncio
    private val omitirCortos = setOf("omitir", "saltar", "skip", "omitir ahora", "skip now", "skip video")
    private val cerrar = setOf(
        "cerrar anuncio", "cerrar publicidad", "close ad",
        "cerrar", "close", "dismiss", "descartar"
    )
    private val simbolosX = setOf("x", "×", "✕", "✖", "╳", "⨉", "ⓧ", "⊗")

    // Nunca saltar intros/resúmenes/créditos
    private val palabrasProhibidas = listOf(
        "intro", "recap", "resumen", "credits", "créditos", "creditos", "episodio", "episode"
    )

    // Nunca presionar esto (abre la tienda, instala o abre más anuncios)
    private val regexNoTocar = Regex(
        """install|instalar|download|descargar|offer|_item|cta|watch now|ver ahora|learn more|más información|mas informacion|privacy|privacidad|choice|feedback|report|mute|sound|volume|silenc|audio|like"""
    )

    private val regexAnuncio = Regex("""\b(anuncios?|publicidad|patrocinado|sponsored|advertisement|ads?)\b""")
    // ExoPlayer siempre trae "exo_ad_overlay" aunque no haya anuncio: no cuenta
    private val regexIdFalsoAnuncio = Regex("""^exo_|ad_overlay""")
    private var ultimaAppAnuncio = ""
    private var motivoActual = ""
    private val regexIdAnuncio = Regex("""(^|[/_.:])(ads?|advert[a-z]*)([_.]|$)""")

    // Empresas de anuncios (por nombre de pantalla, clase o id)
    private val regexSdk = Regex(
        """mbridge|mintegral|applovin|unity3d\.ads|unity3d\.services|ironsource|vungle|liftoff|bytedance|pangle|gms\.ads|facebook\.ads|chartboost|inmobi|adcolony|startapp|appodeal|yandex\.mobile\.ads|interstitial|rewardvideo|rewardedvideo|(^|[._$])ads?(activity|view|webview|container|layout)"""
    )
    private val regexIdCerrar = Regex("""close|cerrar|dismiss|skip|omitir|(^|_)x(_|$)|btn_x|iv_x""")
    private val regexDigito = Regex("""\d""")

    override fun onServiceConnected() {
        super.onServiceConnected()
        AdLog.agregar(this, "Next MC iniciado (v13)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        val pkg = ev.packageName?.toString() ?: return

        // Eventos de nuestras propias capas negras: ignorarlos (si no, se apagaba todo solo).
        // Solo cuenta si de verdad abriste la pantalla de Next MC.
        val abristeNuestraApp = pkg == packageName &&
                (ev.className?.toString() ?: "").endsWith("MainActivity")
        if (pkg == packageName && !abristeNuestraApp) return

        // Apps que tú marcaste como "Ignorar"
        if (Prefs.ignorada(this, pkg)) {
            if (enModoAnuncio) actualizarModoAnuncio(false, forzar = true)
            return
        }

        if (pkg in excluidos) {
            if (pkg in lanzadoresYAjustes || pkg == packageName) {
                if (enModoAnuncio) actualizarModoAnuncio(false, forzar = true)
            }
            return
        }

        var pantallaNueva = false
        if (ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            pantallaNueva = true
            val clase = ev.className?.toString() ?: ""
            val esVista = clase.startsWith("android.widget.") || clase.startsWith("android.view.") ||
                    clase.startsWith("android.app.Dialog")
            if (clase.isNotEmpty() && !esVista && clase != actividadActual) {
                actividadActual = clase
                inicioActividad = SystemClock.elapsedRealtime()
                backsEnAnuncio = 0
                val esPantallaDeAnuncio = regexSdk.containsMatchIn(clase.lowercase())
                if (Prefs.diagnostico(this)) {
                    AdLog.agregar(this, "→ Pantalla: $clase" + if (esPantallaDeAnuncio) "  <<< ANUNCIO" else "")
                }
                // DETECCIÓN INSTANTÁNEA: la pantalla se llama como empresa de anuncios
                // (VungleActivity, MBRewardVideoActivity, AppLovin...): oscurecer y silenciar YA,
                // sin esperar a revisar los botones.
                if (esPantallaDeAnuncio) {
                    motivoActual = "pantalla de anuncios: ${clase.substringAfterLast('.')}"
                    recordarAppConAnuncio(pkg)
                    actualizarModoAnuncio(true)
                }
            }
        }

        reintentos = 0
        // Pantalla nueva: revisar de inmediato. Cambios chiquitos: con calma (ahorro).
        if (pantallaNueva) programarEscaneo(0, inmediato = true) else programarEscaneo(100)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        quitarCapa()
        silenciar(false)
        super.onDestroy()
    }

    private var ultimoEscaneo = 0L
    private val escaneoRunnable = Runnable {
        escaneoPendiente = false
        ultimoEscaneo = SystemClock.elapsedRealtime()
        try {
            escanear()
        } catch (e: Exception) {
            AdLog.agregar(this, "Error: ${e.message}")
        }
    }

    private fun programarEscaneo(retrasoMs: Long, inmediato: Boolean = false) {
        if (inmediato) {
            // Pantalla nueva: cancelar la revisión pendiente y revisar ya
            handler.removeCallbacks(escaneoRunnable)
            escaneoPendiente = true
            handler.postDelayed(escaneoRunnable, retrasoMs)
            return
        }
        if (escaneoPendiente) return
        escaneoPendiente = true
        // Ahorro: sin anuncio en pantalla, máximo ~2 revisiones por segundo
        // (los reproductores mandan muchísimos avisos de "algo cambió")
        val desdeUltimo = SystemClock.elapsedRealtime() - ultimoEscaneo
        val minimo = if (enModoAnuncio) 150L else 450L
        val retraso = maxOf(retrasoMs, minimo - desdeUltimo)
        handler.postDelayed(escaneoRunnable, retraso)
    }

    private fun escanear() {
        val raices = obtenerRaices()
        if (raices.isEmpty()) {
            if (enModoAnuncio) actualizarModoAnuncio(false, forzar = true)
            return
        }

        val nodos = mutableListOf<AccessibilityNodeInfo>()
        for (r in raices) recolectar(r, nodos, 0)
        if (nodos.isEmpty()) return

        val pkg = raices.first().packageName?.toString() ?: "?"
        val pantalla = tamanoPantalla()

        val anuncioPorPantalla = regexSdk.containsMatchIn(actividadActual.lowercase())
        val pantallaArea = tamanoPantalla().let { it.width().toLong() * it.height() }

        // Pieza de empresa de anuncios GRANDE (pantalla completa). Un banner chiquito NO cuenta.
        val sdkGrande = nodos.firstOrNull { n ->
            n.isVisibleToUser && esGrande(n, pantallaArea) &&
                    (regexSdk.containsMatchIn(idCorto(n)) ||
                            regexSdk.containsMatchIn((n.className?.toString() ?: "").lowercase()))
        }
        val anuncioFuerte = anuncioPorPantalla || sdkGrande != null
        val hayAnuncio = anuncioFuerte || nodos.any { it.isVisibleToUser && esSenalDeAnuncio(it) }

        if (Prefs.diagnostico(this)) {
            if (hayAnuncio) diagnostico(pkg, nodos, anuncioFuerte, "ANUNCIO?")
        }

        // ¿Está corriendo un anuncio ahorita? (para oscurecer y silenciar) + el motivo
        var motivo = ""
        if (anuncioPorPantalla) {
            motivo = "pantalla de anuncios: ${actividadActual.substringAfterLast('.')}"
        } else if (sdkGrande != null) {
            motivo = "pieza de anuncios grande: " + describir(sdkGrande)
        } else {
            // id de anuncio con texto, en algo grande (no un banner del menú)
            val porId = nodos.firstOrNull { n ->
                n.isVisibleToUser && esIdDeAnuncio(idCorto(n)) &&
                        (esGrande(n, pantallaArea) ||
                                textos(n).any { t -> regexAnuncioEnCurso.containsMatchIn(t) || t in omitirSeguros })
            }
            if (porId != null) motivo = "id de anuncio: " + describir(porId)
        }
        if (motivo.isEmpty() && hayAnuncio) {
            // textos tipo "Anuncio · 0:15", "Omitir anuncio", "Saltar en 5"
            val porTexto = nodos.firstOrNull { n ->
                n.isVisibleToUser && textos(n).any { t ->
                    regexAnuncioEnCurso.containsMatchIn(t) || t in omitirSeguros ||
                            t.startsWith("omitir en") || t.startsWith("saltar en") || t.startsWith("skip in") ||
                            (t in omitirCortos && n.isClickable)
                }
            }
            if (porTexto != null) motivo = "texto: " + describir(porTexto)
        }
        val enCurso = motivo.isNotEmpty()
        if (enCurso) {
            motivoActual = motivo
            recordarAppConAnuncio(pkg)
        }
        actualizarModoAnuncio(enCurso)

        var elegido: AccessibilityNodeInfo? = null
        var etiqueta = ""
        var mejor = Int.MAX_VALUE
        for (n in nodos) {
            if (!n.isVisibleToUser || !n.isEnabled) continue
            val p = prioridad(n, hayAnuncio, anuncioFuerte, pantalla) ?: continue
            if (p.first < mejor) {
                mejor = p.first
                elegido = n
                etiqueta = p.second
            }
        }

        val ahora = SystemClock.elapsedRealtime()
        val nodo = elegido

        if (nodo == null) {
            // Último recurso: anuncio confirmado de pantalla completa -> botón Atrás
            if (anuncioPorPantalla && ahora - inicioActividad > 6000 &&
                ahora - ultimoBack > 4000 && backsEnAnuncio < 4
            ) {
                ultimoBack = ahora
                backsEnAnuncio++
                performGlobalAction(GLOBAL_ACTION_BACK)
                AdLog.agregar(this, "↩ Atrás en anuncio ($backsEnAnuncio/4)  [$pkg]")
            }
            if (hayAnuncio && reintentos++ < 60) programarEscaneo(800)
            return
        }

        if (ahora - ultimoClic < 1500) {
            programarEscaneo(800)
            return
        }
        ultimoClic = ahora

        // Contar intentos sobre el mismo botón
        if (etiqueta == ultimaEtiqueta) intentosMismo++ else {
            ultimaEtiqueta = etiqueta
            intentosMismo = 1
        }

        // Botones de esquina: solo se presiona el botón mismo (nunca el fondo del anuncio)
        val soloPropio = mejor >= 4
        val esWeb = estaDentroDeWeb(nodo)

        // En anuncios web: 1º toque simulado, 2º clic, 3º toque... hasta que cierre
        val usarToque = esWeb && intentosMismo % 2 == 1
        val ok = if (usarToque) tocar(nodo) else clic(nodo, soloPropio)
        val metodo = if (usarToque) "toque" else "clic"
        AdLog.agregar(
            this,
            (if (ok) "✔ " else "✘ ") + "Intento $intentosMismo ($metodo${if (esWeb) ", web" else ""}) en '" +
                    etiqueta + "'  [" + pkg + "]"
        )
        programarEscaneo(1200)
    }

    // ───────── Oscurecer y silenciar ─────────

    private fun actualizarModoAnuncio(activo: Boolean, forzar: Boolean = false) {
        val ahora = SystemClock.elapsedRealtime()
        handler.removeCallbacks(revisarFin)
        if (activo) {
            ultimoAnuncioVisto = ahora
            if (!enModoAnuncio) {
                enModoAnuncio = true
                AdLog.agregar(this, "▼ Anuncio detectado: oscurecer/silenciar\n   Motivo: $motivoActual")
            }
            if (Prefs.oscurecer(this)) mostrarCapa() else quitarCapa()
            silenciar(Prefs.silenciar(this))
            handler.postDelayed(revisarFin, 1500)   // seguir revisando hasta que termine
        } else if (enModoAnuncio) {
            if (!forzar && ahora - ultimoAnuncioVisto < 700) {
                handler.postDelayed(revisarFin, 300)  // esperar un poquito para no parpadear
                return
            }
            enModoAnuncio = false
            quitarCapa()
            silenciar(false)
            AdLog.agregar(this, "▲ Terminó el anuncio: pantalla y sonido normales")
        }
    }

    private fun mostrarCapa() {
        if (capas.isNotEmpty()) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val marco = FrameLayout(this)
            marco.setBackgroundColor(Color.argb(248, 0, 0, 0))

            // Logo de Next MC + hora + segundos del anuncio, al centro
            val columna = LinearLayout(this)
            columna.orientation = LinearLayout.VERTICAL
            columna.gravity = Gravity.CENTER_HORIZONTAL
            val dp = resources.displayMetrics.density
            val logo = ImageView(this)
            logo.setImageResource(R.mipmap.ic_launcher)
            logo.alpha = 0.85f
            columna.addView(logo, LinearLayout.LayoutParams((110 * dp).toInt(), (110 * dp).toInt()))
            val nombre = TextView(this)
            nombre.text = "Next MC"
            nombre.setTextColor(Color.argb(200, 34, 211, 238))
            nombre.textSize = 22f
            nombre.gravity = Gravity.CENTER
            nombre.setPadding(0, (10 * dp).toInt(), 0, (18 * dp).toInt())
            columna.addView(nombre)
            val texto = TextView(this)
            texto.setTextColor(Color.argb(170, 255, 255, 255))
            texto.textSize = 22f
            texto.gravity = Gravity.CENTER
            columna.addView(texto)
            marco.addView(
                columna,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
            textoCapa = texto
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(marco, lp)
            capas.add(marco)
            inicioCapa = SystemClock.elapsedRealtime()
            handler.removeCallbacks(relojCapa)
            relojCapa.run()
        } catch (e: Exception) {
            AdLog.agregar(this, "No pude oscurecer: ${e.message}")
        }
    }

    private fun quitarCapa() {
        handler.removeCallbacks(relojCapa)
        textoCapa = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (c in capas) {
            try {
                wm.removeView(c)
            } catch (e: Exception) {
            }
        }
        capas.clear()
    }

    private fun silenciar(si: Boolean) {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            if (si && !silenciadoPorMi) {
                if (!am.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                    silenciadoPorMi = true
                }
            } else if (!si && silenciadoPorMi) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                silenciadoPorMi = false
            }
        } catch (e: Exception) {
            AdLog.agregar(this, "No pude cambiar el sonido: ${e.message}")
        }
    }

    private fun recordarAppConAnuncio(pkg: String) {
        if (pkg.isNotEmpty() && pkg != ultimaAppAnuncio) {
            ultimaAppAnuncio = pkg
            Prefs.setUltimaApp(this, pkg)
        }
    }

    // ───────── Búsqueda de botones ─────────

    private fun obtenerRaices(): List<AccessibilityNodeInfo> {
        val lista = mutableListOf<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                if ((r.packageName?.toString() ?: "") in excluidos) continue
                lista.add(r)
            }
        } catch (e: Exception) {
        }
        if (lista.isEmpty()) {
            val r = rootInActiveWindow
            if (r != null && (r.packageName?.toString() ?: "") !in excluidos) lista.add(r)
        }
        return lista
    }

    private fun recolectar(n: AccessibilityNodeInfo, salida: MutableList<AccessibilityNodeInfo>, profundidad: Int) {
        if (salida.size > 2000 || profundidad > 50) return
        salida.add(n)
        for (i in 0 until n.childCount) {
            val hijo = n.getChild(i) ?: continue
            recolectar(hijo, salida, profundidad + 1)
        }
    }

    private fun tamanoPantalla(): Rect {
        val dm = resources.displayMetrics
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    private fun textos(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.text, n.contentDescription)
            .map { normalizar(it.toString()) }
            .filter { it.isNotEmpty() }

    private fun normalizar(s: String): String =
        s.lowercase().trim().trim('›', '>', '▶', '▸', '►', '⏭', '|', '»', ' ').trim()

    private fun idCorto(n: AccessibilityNodeInfo): String =
        n.viewIdResourceName?.lowercase()?.substringAfter(":id/") ?: ""

    private fun esSenalDeAnuncio(n: AccessibilityNodeInfo): Boolean {
        if (textos(n).any { regexAnuncio.containsMatchIn(it) }) return true
        return esIdDeAnuncio(idCorto(n))
    }

    /** ¿Ocupa buena parte de la pantalla? (anuncio de verdad, no un banner chiquito) */
    private fun esGrande(n: AccessibilityNodeInfo, pantallaArea: Long): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty || pantallaArea <= 0) return false
        return r.width().toLong() * r.height() >= pantallaArea * 0.40
    }

    private fun describir(n: AccessibilityNodeInfo): String {
        val id = idCorto(n)
        val t = (n.text ?: n.contentDescription)?.toString()?.replace('\n', ' ')?.take(40) ?: ""
        val clase = n.className?.toString()?.substringAfterLast('.') ?: ""
        return buildString {
            if (id.isNotEmpty()) append("id=$id ")
            if (t.isNotEmpty()) append("t='$t' ")
            append("($clase)")
        }
    }

    private fun esIdDeAnuncio(id: String): Boolean =
        id.isNotEmpty() && regexIdAnuncio.containsMatchIn(id) && !regexIdFalsoAnuncio.containsMatchIn(id)

    /** (prioridad, etiqueta). Menor = mejor. */
    private fun prioridad(
        n: AccessibilityNodeInfo,
        hayAnuncio: Boolean,
        anuncioFuerte: Boolean,
        pantalla: Rect
    ): Pair<Int, String>? {
        val ts = textos(n)
        val id = idCorto(n)

        if (ts.any { regexDigito.containsMatchIn(it) }) return null           // "Omitir en 5"
        if ((ts + id).any { t -> palabrasProhibidas.any { it in t } }) return null
        // Install, ofertas, etc. (un id de cerrar como "..._close" sí se permite)
        if (ts.any { regexNoTocar.containsMatchIn(it) }) return null
        if (regexNoTocar.containsMatchIn(id) && !regexIdCerrar.containsMatchIn(id)) return null

        for (t in ts) {
            if (t in omitirSeguros || t.startsWith("omitir anuncio") || t.startsWith("skip ad")) return 1 to t
            if (hayAnuncio && t in omitirCortos) return 2 to t
            if (hayAnuncio && (t in cerrar || t in simbolosX)) return 3 to t
        }

        if (id.isNotEmpty() && hayAnuncio) {
            val esCerrar = regexIdCerrar.containsMatchIn(id)
            if (esCerrar && (anuncioFuerte || esIdDeAnuncio(id) || regexSdk.containsMatchIn(id))) {
                return 3 to "id:$id"
            }
        }

        // X sin texto en una esquina de arriba (solo en anuncios confirmados)
        if (anuncioFuerte && (n.isClickable || n.isFocusable)) {
            val lado = ladoEsquina(n, pantalla)
            if (lado != 0 && ts.none { it.length > 2 && it !in cerrar }) {
                val nombre = if (id.isNotEmpty()) id else (n.className?.toString()?.substringAfterLast('.') ?: "?")
                return (if (lado == 1) 4 else 5) to "esquina:$nombre"
            }
        }
        return null
    }

    /** 1 = esquina superior derecha, 2 = superior izquierda, 0 = no es esquina. */
    private fun ladoEsquina(n: AccessibilityNodeInfo, pantalla: Rect): Int {
        if (pantalla.isEmpty) return 0
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return 0
        val w = pantalla.width()
        val h = pantalla.height()
        if (r.width() > w * 0.12 || r.height() > h * 0.20) return 0
        if (r.top > pantalla.top + h * 0.22) return 0
        if (r.right >= pantalla.right - w * 0.15) return 1
        if (r.left <= pantalla.left + w * 0.15) return 2
        return 0
    }

    /** ¿El botón está dentro de una página web (WebView)? */
    private fun estaDentroDeWeb(nodo: AccessibilityNodeInfo): Boolean {
        var actual: AccessibilityNodeInfo? = nodo
        var nivel = 0
        while (actual != null && nivel < 40) {
            val clase = actual.className?.toString() ?: ""
            if ("WebView" in clase) return true
            actual = actual.parent
            nivel++
        }
        return false
    }

    /** Toque simulado en el centro del botón. */
    private fun tocar(nodo: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        nodo.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesto = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesto, null, null)
    }

    private fun clic(nodo: AccessibilityNodeInfo, soloPropio: Boolean): Boolean {
        if (!soloPropio) {
            var actual: AccessibilityNodeInfo? = nodo
            var nivel = 0
            while (actual != null && nivel < 6) {
                if (actual.isClickable && actual.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                actual = actual.parent
                nivel++
            }
        }
        if (nodo.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

        // Plan B: "tocar" el centro del botón
        val r = Rect()
        nodo.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesto = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesto, null, null)
    }

    /** Diagnóstico (solo en pantallas con anuncio). Primero los posibles botones de cerrar. */
    private fun diagnostico(pkg: String, nodos: List<AccessibilityNodeInfo>, anuncioFuerte: Boolean, titulo: String) {
        val ahora = SystemClock.elapsedRealtime()
        if (ahora - ultimoDiagnostico < 4000) return

        val pantalla = tamanoPantalla()
        val importantes = mutableListOf<String>()
        val resto = mutableListOf<String>()
        for (n in nodos) {
            if (!n.isVisibleToUser) continue
            val txt = n.text?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val desc = n.contentDescription?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val id = idCorto(n)
            val clase = n.className?.toString()?.substringAfterLast('.') ?: ""
            val r = Rect()
            n.getBoundsInScreen(r)
            val clic = if (n.isClickable) " [clic]" else ""
            val linea = " · t='${txt.take(30)}' d='${desc.take(30)}' id=$id ($clase) @${r.left},${r.top}$clic"
            val esImportante = regexIdCerrar.containsMatchIn(id) ||
                    textos(n).any { it in cerrar || it in simbolosX || it in omitirCortos || it in omitirSeguros } ||
                    ((n.isClickable || n.isFocusable) && ladoEsquina(n, pantalla) != 0)
            if (esImportante) importantes.add("★$linea")
            else if (txt.isNotEmpty() || desc.isNotEmpty() || id.isNotEmpty() || n.isClickable) resto.add(linea)
        }
        val lineas = importantes.take(40) + resto.take(60)

        val huella = lineas.hashCode()
        if (huella == ultimaHuellaDiagnostico) return
        ultimaHuellaDiagnostico = huella
        ultimoDiagnostico = ahora

        AdLog.agregar(
            this,
            "══ $titulo en $pkg (fuerte=${if (anuncioFuerte) "SÍ" else "no"}) " +
                    "pantalla=${actividadActual.substringAfterLast('.')} ══\n" +
                    " (nodos totales: ${nodos.size})\n" +
                    (if (importantes.isEmpty()) " (no encontré botón de cerrar)\n" else "") +
                    lineas.joinToString("\n")
        )
    }
}
