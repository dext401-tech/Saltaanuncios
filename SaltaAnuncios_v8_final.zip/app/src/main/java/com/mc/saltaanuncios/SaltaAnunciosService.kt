package com.mc.saltaanuncios

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * Salta Anuncios MC - versión 8 (final)
 * NO bloquea anuncios. Cuando la app ya ofrece "Omitir", "Saltar", "Skip"
 * o la X para cerrar, este servicio la presiona por ti.
 * v2: reconoce anuncios de pantalla completa de empresas de anuncios
 * (Mintegral/mbridge, AppLovin, Unity, AdMob, etc.) y su X sin texto.
 * v3: oscurece la pantalla y silencia mientras dura el anuncio.
 * v4: anuncios hechos como página web (Vungle/Liftoff, etc.): alterna
 *     "toque" simulado y clic, y reintenta hasta que la X funcione.
 * v8: "ojo" para YouTube: como YouTube TV no deja ver sus botones, lee la
 *     pantalla (captura en memoria + lector de texto) SOLO mientras YouTube
 *     está abierto. Oscurece todo menos 2 cuadritos ("Saltar" y "Patrocinado") y toca "Saltar".
 */
class SaltaAnunciosService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var escaneoPendiente = false
    private var ultimoClic = 0L
    private var ultimaEtiqueta = ""
    private var intentosMismo = 0
    private var reintentos = 0
    private var ultimoDiagnostico = 0L
    private var ultimaHuellaDiagnostico = 0

    // Pantalla (actividad) actual
    private var actividadActual = ""
    private var inicioActividad = 0L
    private var backsEnAnuncio = 0
    private var ultimoBack = 0L

    // ───── Ojo para YouTube ─────
    private val paquetesYoutube = setOf(
        "com.google.android.youtube.tv",
        "com.google.android.youtube.googletv",
        "com.google.android.youtube"
    )
    private val lanzadoresYAjustes = setOf(
        "com.android.tv.settings", "com.android.settings",
        "com.google.android.tvlauncher", "com.google.android.apps.tv.launcherx",
        "com.google.android.leanbacklauncher"
    )
    private var paqueteEnFrente = ""
    private var ojoActivo = false
    private var ojoOcupado = false
    private var ultimoOjoAnuncio = 0L
    private var ultimoToqueOjo = 0L
    private var ultimoErrorOjo = 0L
    private var ultimoTextoOjo = ""
    private var ultimoLogOjo = 0L
    private var reconocedor: TextRecognizer? = null
    private val regexOjoAnuncio = Regex("""patrocinad|anuncio|sponsored|saltar|omitir|skip""")
    private val regexOjoBoton = Regex("""saltar|omitir|skip""")
    private val ojoRunnable = object : Runnable {
        override fun run() {
            if (!ojoActivo) return
            mirarPantalla()
            handler.postDelayed(this, 1000)
        }
    }

    // Modo anuncio (oscurecer + silenciar)
    private var capaConHueco = false
    private val capas = mutableListOf<View>()
    private var textoCapa: TextView? = null
    private var inicioCapa = 0L
    private val formatoHora = java.text.SimpleDateFormat("h:mm a", java.util.Locale("es", "MX"))
    private val relojCapa = object : Runnable {
        override fun run() {
            val t = textoCapa ?: return
            val seg = (SystemClock.elapsedRealtime() - inicioCapa) / 1000
            t.text = "🕒 " + formatoHora.format(java.util.Date()) +
                    "\n\nAnuncio en curso · " + seg + " s" +
                    "\nLo quito en cuanto salga la X"
            handler.postDelayed(this, 1000)
        }
    }
    private var silenciadoPorMi = false
    private var enModoAnuncio = false
    private var ultimoAnuncioVisto = 0L
    private val revisarFin = Runnable {
        reintentos = 0
        programarEscaneo(0)
    }
    private val regexAnuncioEnCurso = Regex("""(anuncio|patrocinado|sponsored|\bad)\s*[·•:]?\s*\d""")

    // Apps donde nunca hace nada
    private val excluidos = setOf(
        "com.mc.saltaanuncios",
        "com.android.tv.settings",
        "com.android.settings",
        "com.android.systemui",
        "com.google.android.tvlauncher",
        "com.google.android.apps.tv.launcherx",
        "com.google.android.leanbacklauncher"
    )

    // Botones que SIEMPRE son de anuncio
    private val omitirSeguros = setOf(
        "omitir anuncio", "omitir anuncios", "omitir publicidad",
        "saltar anuncio", "saltar anuncios", "saltar publicidad",
        "skip ad", "skip ads", "skip advertisement"
    )
    // Botones cortos: solo con señales de anuncio
    private val omitirCortos = setOf("omitir", "saltar", "skip", "omitir ahora", "skip now", "skip video")
    private val cerrar = setOf(
        "cerrar anuncio", "cerrar publicidad", "close ad",
        "cerrar", "close", "dismiss", "descartar"
    )
    private val simbolosX = setOf("x", "×", "✕", "✖", "╳", "⨉", "ⓧ", "⊗")

    // Nunca saltar intros/resúmenes/créditos
    private val palabrasProhibidas = listOf(
        "intro", "recap", "resumen", "credits", "créditos", "creditos", "episodio", "episode"
    )

    // Nunca presionar esto (abre la tienda, instala o abre más anuncios)
    private val regexNoTocar = Regex(
        """install|instalar|download|descargar|offer|_item|cta|watch now|ver ahora|learn more|más información|mas informacion|privacy|privacidad|choice|feedback|report|mute|sound|volume|silenc|audio|like"""
    )

    private val regexAnuncio = Regex("""\b(anuncios?|publicidad|patrocinado|sponsored|advertisement|ads?)\b""")
    private val regexIdAnuncio = Regex("""(^|[/_.:])(ads?|advert[a-z]*)([_.]|$)""")

    // Empresas de anuncios (por nombre de pantalla, clase o id)
    private val regexSdk = Regex(
        """mbridge|mintegral|applovin|unity3d\.ads|unity3d\.services|ironsource|vungle|liftoff|bytedance|pangle|gms\.ads|facebook\.ads|chartboost|inmobi|adcolony|startapp|appodeal|yandex\.mobile\.ads|interstitial|rewardvideo|rewardedvideo|(^|[._$])ads?(activity|view|webview|container|layout)"""
    )
    private val regexIdCerrar = Regex("""close|cerrar|dismiss|skip|omitir|(^|_)x(_|$)|btn_x|iv_x""")
    private val regexDigito = Regex("""\d""")

    override fun onServiceConnected() {
        super.onServiceConnected()
        AdLog.agregar(this, "Servicio iniciado (v8)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        val pkg = ev.packageName?.toString() ?: return

        if (ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != "com.android.systemui") {
            if (pkg != paqueteEnFrente) {
                paqueteEnFrente = pkg
                actualizarOjo()
            }
        }

        if (pkg in excluidos) {
            if (pkg in lanzadoresYAjustes || pkg == packageName) {
                if (enModoAnuncio) actualizarModoAnuncio(false, forzar = true)
            }
            return
        }

        if (ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val clase = ev.className?.toString() ?: ""
            val esVista = clase.startsWith("android.widget.") || clase.startsWith("android.view.") ||
                    clase.startsWith("android.app.Dialog")
            if (clase.isNotEmpty() && !esVista && clase != actividadActual) {
                actividadActual = clase
                inicioActividad = SystemClock.elapsedRealtime()
                backsEnAnuncio = 0
                if (Prefs.diagnostico(this)) {
                    val marca = if (regexSdk.containsMatchIn(clase.lowercase())) "  <<< ANUNCIO" else ""
                    AdLog.agregar(this, "→ Pantalla: $clase$marca")
                }
            }
        }

        reintentos = 0
        programarEscaneo(150)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        apagarOjo()
        quitarCapa()
        silenciar(false)
        super.onDestroy()
    }

    private fun programarEscaneo(retrasoMs: Long) {
        if (escaneoPendiente) return
        escaneoPendiente = true
        handler.postDelayed({
            escaneoPendiente = false
            try {
                escanear()
            } catch (e: Exception) {
                AdLog.agregar(this, "Error: ${e.message}")
            }
        }, retrasoMs)
    }

    private fun escanear() {
        val raices = obtenerRaices()
        if (raices.isEmpty()) {
            if (enModoAnuncio) actualizarModoAnuncio(false, forzar = true)
            return
        }

        val nodos = mutableListOf<AccessibilityNodeInfo>()
        for (r in raices) recolectar(r, nodos, 0)
        if (nodos.isEmpty()) return

        val pkg = raices.first().packageName?.toString() ?: "?"
        val pantalla = tamanoPantalla()

        val anuncioPorPantalla = regexSdk.containsMatchIn(actividadActual.lowercase())
        val anuncioFuerte = anuncioPorPantalla || nodos.any { n ->
            n.isVisibleToUser && (regexSdk.containsMatchIn(idCorto(n)) ||
                    regexSdk.containsMatchIn((n.className?.toString() ?: "").lowercase()))
        }
        val hayAnuncio = anuncioFuerte || nodos.any { it.isVisibleToUser && esSenalDeAnuncio(it) }

        if (Prefs.diagnostico(this)) {
            if (hayAnuncio) diagnostico(pkg, nodos, anuncioFuerte, "ANUNCIO")
            else if ("youtube" in pkg) diagnostico(pkg, nodos, false, "YOUTUBE (sin anuncio detectado)")
        }

        // ¿Está corriendo un anuncio ahorita? (para oscurecer y silenciar)
        val enCurso = anuncioFuerte || nodos.any { n ->
            // ids tipo "ad_progress_text", "skip_ad_button", "ad_badge" (YouTube y otros)
            n.isVisibleToUser && idCorto(n).let { it.isNotEmpty() && regexIdAnuncio.containsMatchIn(it) }
        } || (hayAnuncio && nodos.any { n ->
            n.isVisibleToUser && textos(n).any { t ->
                regexAnuncioEnCurso.containsMatchIn(t) || t in omitirSeguros || t in omitirCortos ||
                        t.startsWith("omitir en") || t.startsWith("saltar en") || t.startsWith("skip in")
            }
        })
        actualizarModoAnuncio(enCurso || ojoVioAnuncioReciente())

        var elegido: AccessibilityNodeInfo? = null
        var etiqueta = ""
        var mejor = Int.MAX_VALUE
        for (n in nodos) {
            if (!n.isVisibleToUser || !n.isEnabled) continue
            val p = prioridad(n, hayAnuncio, anuncioFuerte, pantalla) ?: continue
            if (p.first < mejor) {
                mejor = p.first
                elegido = n
                etiqueta = p.second
            }
        }

        val ahora = SystemClock.elapsedRealtime()
        val nodo = elegido

        if (nodo == null) {
            // Último recurso: anuncio confirmado de pantalla completa -> botón Atrás
            if (anuncioPorPantalla && ahora - inicioActividad > 6000 &&
                ahora - ultimoBack > 4000 && backsEnAnuncio < 4
            ) {
                ultimoBack = ahora
                backsEnAnuncio++
                performGlobalAction(GLOBAL_ACTION_BACK)
                AdLog.agregar(this, "↩ Atrás en anuncio ($backsEnAnuncio/4)  [$pkg]")
            }
            if (hayAnuncio && reintentos++ < 60) programarEscaneo(800)
            return
        }

        if (ahora - ultimoClic < 1500) {
            programarEscaneo(800)
            return
        }
        ultimoClic = ahora

        // Contar intentos sobre el mismo botón
        if (etiqueta == ultimaEtiqueta) intentosMismo++ else {
            ultimaEtiqueta = etiqueta
            intentosMismo = 1
        }

        // Botones de esquina: solo se presiona el botón mismo (nunca el fondo del anuncio)
        val soloPropio = mejor >= 4
        val esWeb = estaDentroDeWeb(nodo)

        // En anuncios web: 1º toque simulado, 2º clic, 3º toque... hasta que cierre
        val usarToque = esWeb && intentosMismo % 2 == 1
        val ok = if (usarToque) tocar(nodo) else clic(nodo, soloPropio)
        val metodo = if (usarToque) "toque" else "clic"
        AdLog.agregar(
            this,
            (if (ok) "✔ " else "✘ ") + "Intento $intentosMismo ($metodo${if (esWeb) ", web" else ""}) en '" +
                    etiqueta + "'  [" + pkg + "]"
        )
        programarEscaneo(1200)
    }

    // ───────── Oscurecer y silenciar ─────────

    private fun actualizarModoAnuncio(activo: Boolean, forzar: Boolean = false) {
        val ahora = SystemClock.elapsedRealtime()
        handler.removeCallbacks(revisarFin)
        if (activo) {
            ultimoAnuncioVisto = ahora
            if (!enModoAnuncio) {
                enModoAnuncio = true
                AdLog.agregar(this, "▼ Anuncio detectado: oscurecer/silenciar")
            }
            if (Prefs.oscurecer(this)) mostrarCapa(conHueco = ojoActivo) else quitarCapa()
            silenciar(Prefs.silenciar(this))
            handler.postDelayed(revisarFin, 1500)   // seguir revisando hasta que termine
        } else if (enModoAnuncio) {
            if (!forzar && ahora - ultimoAnuncioVisto < 1500) {
                handler.postDelayed(revisarFin, 800)  // esperar un poco para no parpadear
                return
            }
            enModoAnuncio = false
            quitarCapa()
            silenciar(false)
            AdLog.agregar(this, "▲ Terminó el anuncio: pantalla y sonido normales")
        }
    }

    /**
     * Huecos que se dejan destapados en YouTube (en fracciones de la pantalla):
     *  - abajo a la derecha: el botón "Saltar"
     *  - abajo a la izquierda: el texto "Patrocinado" (para anuncios sin "Saltar")
     */
    private val huecosYoutube = listOf(
        floatArrayOf(0.78f, 0.80f, 1.00f, 0.97f),   // izq, arriba, der, abajo
        floatArrayOf(0.00f, 0.82f, 0.36f, 0.96f)
    )
    private val lecturaArriba = 0.80f
    private val lecturaAbajo = 0.97f

    /** Rectángulos que tapan toda la pantalla menos los huecos. */
    private fun rectangulosQueTapan(w: Int, h: Int, huecos: List<Rect>): List<Rect> {
        val ys = sortedSetOf(0, h)
        for (hu in huecos) { ys.add(hu.top); ys.add(hu.bottom) }
        val lista = ys.toList()
        val salida = mutableListOf<Rect>()
        for (i in 0 until lista.size - 1) {
            val y1 = lista[i]
            val y2 = lista[i + 1]
            if (y2 <= y1) continue
            // huecos que cruzan esta banda, ordenados de izquierda a derecha
            val enBanda = huecos.filter { it.top < y2 && it.bottom > y1 }.sortedBy { it.left }
            var x = 0
            for (hu in enBanda) {
                if (hu.left > x) salida.add(Rect(x, y1, hu.left, y2))
                x = maxOf(x, hu.right)
            }
            if (x < w) salida.add(Rect(x, y1, w, y2))
        }
        return salida
    }

    private fun mostrarCapa(conHueco: Boolean) {
        if (capas.isNotEmpty() && capaConHueco == conHueco) return
        if (capas.isNotEmpty()) quitarCapa()
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val real = tamanoReal()
            val rects = if (conHueco) {
                val huecos = huecosYoutube.map {
                    Rect((it[0] * real.x).toInt(), (it[1] * real.y).toInt(), (it[2] * real.x).toInt(), (it[3] * real.y).toInt())
                }
                rectangulosQueTapan(real.x, real.y, huecos)
            } else listOf(Rect(0, 0, real.x, real.y))

            // El rectángulo más grande lleva el reloj y el aviso
            val grande = rects.maxByOrNull { it.width().toLong() * it.height() }
            for (r in rects) {
                val marco = FrameLayout(this)
                marco.setBackgroundColor(Color.argb(248, 0, 0, 0))
                if (r == grande) {
                    val texto = TextView(this)
                    texto.setTextColor(Color.argb(170, 255, 255, 255))
                    texto.textSize = 26f
                    texto.gravity = Gravity.CENTER
                    marco.addView(
                        texto,
                        FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
                    )
                    textoCapa = texto
                }
                val lp = WindowManager.LayoutParams(
                    r.width(),
                    r.height(),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                lp.x = r.left
                lp.y = r.top
                wm.addView(marco, lp)
                capas.add(marco)
            }
            capaConHueco = conHueco
            inicioCapa = SystemClock.elapsedRealtime()
            handler.removeCallbacks(relojCapa)
            relojCapa.run()
        } catch (e: Exception) {
            AdLog.agregar(this, "No pude oscurecer: ${e.message}")
        }
    }

    private fun quitarCapa() {
        handler.removeCallbacks(relojCapa)
        textoCapa = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (c in capas) {
            try {
                wm.removeView(c)
            } catch (e: Exception) {
            }
        }
        capas.clear()
    }

    private fun silenciar(si: Boolean) {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            if (si && !silenciadoPorMi) {
                if (!am.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                    silenciadoPorMi = true
                }
            } else if (!si && silenciadoPorMi) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                silenciadoPorMi = false
            }
        } catch (e: Exception) {
            AdLog.agregar(this, "No pude cambiar el sonido: ${e.message}")
        }
    }

    // ───────── Ojo para YouTube ─────────

    private fun ojoVioAnuncioReciente(): Boolean =
        ojoActivo && SystemClock.elapsedRealtime() - ultimoOjoAnuncio < 2500

    private fun actualizarOjo() {
        val debe = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                Prefs.modoYoutube(this) && paqueteEnFrente in paquetesYoutube
        if (debe && !ojoActivo) {
            ojoActivo = true
            ojoOcupado = false
            AdLog.agregar(this, "👁 Ojo encendido (YouTube abierto)")
            handler.removeCallbacks(ojoRunnable)
            handler.postDelayed(ojoRunnable, 500)
        } else if (!debe && ojoActivo) {
            apagarOjo()
            AdLog.agregar(this, "👁 Ojo apagado")
            if (enModoAnuncio) actualizarModoAnuncio(false, forzar = true)
        }
    }

    private fun apagarOjo() {
        ojoActivo = false
        handler.removeCallbacks(ojoRunnable)
        try {
            reconocedor?.close()
        } catch (e: Exception) {
        }
        reconocedor = null
    }

    @Suppress("DEPRECATION")
    private fun tamanoReal(): Point {
        val p = Point()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(p)
        return p
    }

    @SuppressLint("NewApi")
    private fun mirarPantalla() {
        if (ojoOcupado || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        ojoOcupado = true
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(resultado: AccessibilityService.ScreenshotResult) {
                        procesarCaptura(resultado)
                    }

                    override fun onFailure(codigo: Int) {
                        ojoOcupado = false
                        val ahora = SystemClock.elapsedRealtime()
                        if (ahora - ultimoErrorOjo > 15000) {
                            ultimoErrorOjo = ahora
                            AdLog.agregar(
                                this@SaltaAnunciosService,
                                "👁 No pude leer la pantalla (código $codigo). " +
                                        "Si sigue, apaga y prende el servicio en Accesibilidad."
                            )
                        }
                    }
                })
        } catch (e: Exception) {
            ojoOcupado = false
            AdLog.agregar(this, "👁 Error al leer pantalla: ${e.message}")
        }
    }

    @SuppressLint("NewApi")
    private fun procesarCaptura(resultado: AccessibilityService.ScreenshotResult) {
        val buffer = resultado.hardwareBuffer
        var completa: Bitmap? = null
        try {
            val hw = Bitmap.wrapHardwareBuffer(buffer, resultado.colorSpace)
            completa = hw?.copy(Bitmap.Config.ARGB_8888, false)
            hw?.recycle()
        } catch (e: Exception) {
        } finally {
            buffer.close()
        }
        val bmp = completa
        if (bmp == null) {
            ojoOcupado = false
            return
        }

        // Solo se lee la parte de abajo (donde están los cuadritos destapados)
        val ancho = bmp.width
        val altoTotal = bmp.height
        val y0 = (altoTotal * lecturaArriba).toInt()
        val y1 = (altoTotal * lecturaAbajo).toInt()
        val recorte = Bitmap.createBitmap(bmp, 0, y0, ancho, y1 - y0)
        if (recorte != bmp) bmp.recycle()

        val rec = reconocedor ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).also {
            reconocedor = it
        }
        rec.process(InputImage.fromBitmap(recorte, 0))
            .addOnSuccessListener { texto -> analizarTexto(texto, y0, ancho, altoTotal) }
            .addOnCompleteListener {
                ojoOcupado = false
                recorte.recycle()
            }
    }

    private fun analizarTexto(texto: Text, y0: Int, ancho: Int, altoTotal: Int) {
        if (!ojoActivo) return
        val ahora = SystemClock.elapsedRealtime()
        val todo = texto.text.lowercase().replace('\n', ' ')

        if (Prefs.diagnostico(this) && todo.isNotBlank() && todo != ultimoTextoOjo && ahora - ultimoLogOjo > 3000) {
            ultimoTextoOjo = todo
            ultimoLogOjo = ahora
            AdLog.agregar(this, "👁 Leí: '${todo.take(90)}'")
        }

        val hayAnuncio = regexOjoAnuncio.containsMatchIn(todo)
        if (hayAnuncio) ultimoOjoAnuncio = ahora
        actualizarModoAnuncio(hayAnuncio || ojoVioAnuncioReciente())
        if (!hayAnuncio) return

        // Buscar el botón "Saltar" / "Omitir" / "Skip" y tocarlo
        if (ahora - ultimoToqueOjo < 2000) return
        val real = tamanoReal()
        val escalaX = real.x.toFloat() / ancho
        val escalaY = real.y.toFloat() / altoTotal
        for (bloque in texto.textBlocks) {
            for (linea in bloque.lines) {
                if (!regexOjoBoton.containsMatchIn(linea.text.lowercase())) continue
                val caja = linea.boundingBox ?: continue
                val x = caja.exactCenterX() * escalaX
                val y = (caja.exactCenterY() + y0) * escalaY
                ultimoToqueOjo = ahora
                val ok = tocarEn(x, y)
                AdLog.agregar(
                    this,
                    (if (ok) "👆 Toqué '" else "✘ No pude tocar '") + linea.text + "' en YouTube"
                )
                return
            }
        }
    }

    private fun tocarEn(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesto = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesto, null, null)
    }

    // ───────── Búsqueda de botones ─────────

    private fun obtenerRaices(): List<AccessibilityNodeInfo> {
        val lista = mutableListOf<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                if ((r.packageName?.toString() ?: "") in excluidos) continue
                lista.add(r)
            }
        } catch (e: Exception) {
        }
        if (lista.isEmpty()) {
            val r = rootInActiveWindow
            if (r != null && (r.packageName?.toString() ?: "") !in excluidos) lista.add(r)
        }
        return lista
    }

    private fun recolectar(n: AccessibilityNodeInfo, salida: MutableList<AccessibilityNodeInfo>, profundidad: Int) {
        if (salida.size > 3000 || profundidad > 60) return
        salida.add(n)
        for (i in 0 until n.childCount) {
            val hijo = n.getChild(i) ?: continue
            recolectar(hijo, salida, profundidad + 1)
        }
    }

    private fun tamanoPantalla(): Rect {
        val dm = resources.displayMetrics
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    private fun textos(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.text, n.contentDescription)
            .map { normalizar(it.toString()) }
            .filter { it.isNotEmpty() }

    private fun normalizar(s: String): String =
        s.lowercase().trim().trim('›', '>', '▶', '▸', '►', '⏭', '|', '»', ' ').trim()

    private fun idCorto(n: AccessibilityNodeInfo): String =
        n.viewIdResourceName?.lowercase()?.substringAfter(":id/") ?: ""

    private fun esSenalDeAnuncio(n: AccessibilityNodeInfo): Boolean {
        if (textos(n).any { regexAnuncio.containsMatchIn(it) }) return true
        val id = idCorto(n)
        return id.isNotEmpty() && regexIdAnuncio.containsMatchIn(id)
    }

    /** (prioridad, etiqueta). Menor = mejor. */
    private fun prioridad(
        n: AccessibilityNodeInfo,
        hayAnuncio: Boolean,
        anuncioFuerte: Boolean,
        pantalla: Rect
    ): Pair<Int, String>? {
        val ts = textos(n)
        val id = idCorto(n)

        if (ts.any { regexDigito.containsMatchIn(it) }) return null           // "Omitir en 5"
        if ((ts + id).any { t -> palabrasProhibidas.any { it in t } }) return null
        // Install, ofertas, etc. (un id de cerrar como "..._close" sí se permite)
        if (ts.any { regexNoTocar.containsMatchIn(it) }) return null
        if (regexNoTocar.containsMatchIn(id) && !regexIdCerrar.containsMatchIn(id)) return null

        for (t in ts) {
            if (t in omitirSeguros || t.startsWith("omitir anuncio") || t.startsWith("skip ad")) return 1 to t
            if (hayAnuncio && t in omitirCortos) return 2 to t
            if (hayAnuncio && (t in cerrar || t in simbolosX)) return 3 to t
        }

        if (id.isNotEmpty() && hayAnuncio) {
            val esCerrar = regexIdCerrar.containsMatchIn(id)
            if (esCerrar && (anuncioFuerte || regexIdAnuncio.containsMatchIn(id) || regexSdk.containsMatchIn(id))) {
                return 3 to "id:$id"
            }
        }

        // X sin texto en una esquina de arriba (solo en anuncios confirmados)
        if (anuncioFuerte && (n.isClickable || n.isFocusable)) {
            val lado = ladoEsquina(n, pantalla)
            if (lado != 0 && ts.none { it.length > 2 && it !in cerrar }) {
                val nombre = if (id.isNotEmpty()) id else (n.className?.toString()?.substringAfterLast('.') ?: "?")
                return (if (lado == 1) 4 else 5) to "esquina:$nombre"
            }
        }
        return null
    }

    /** 1 = esquina superior derecha, 2 = superior izquierda, 0 = no es esquina. */
    private fun ladoEsquina(n: AccessibilityNodeInfo, pantalla: Rect): Int {
        if (pantalla.isEmpty) return 0
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return 0
        val w = pantalla.width()
        val h = pantalla.height()
        if (r.width() > w * 0.12 || r.height() > h * 0.20) return 0
        if (r.top > pantalla.top + h * 0.22) return 0
        if (r.right >= pantalla.right - w * 0.15) return 1
        if (r.left <= pantalla.left + w * 0.15) return 2
        return 0
    }

    /** ¿El botón está dentro de una página web (WebView)? */
    private fun estaDentroDeWeb(nodo: AccessibilityNodeInfo): Boolean {
        var actual: AccessibilityNodeInfo? = nodo
        var nivel = 0
        while (actual != null && nivel < 40) {
            val clase = actual.className?.toString() ?: ""
            if ("WebView" in clase) return true
            actual = actual.parent
            nivel++
        }
        return false
    }

    /** Toque simulado en el centro del botón. */
    private fun tocar(nodo: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        nodo.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesto = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesto, null, null)
    }

    private fun clic(nodo: AccessibilityNodeInfo, soloPropio: Boolean): Boolean {
        if (!soloPropio) {
            var actual: AccessibilityNodeInfo? = nodo
            var nivel = 0
            while (actual != null && nivel < 6) {
                if (actual.isClickable && actual.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                actual = actual.parent
                nivel++
            }
        }
        if (nodo.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

        // Plan B: "tocar" el centro del botón
        val r = Rect()
        nodo.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesto = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesto, null, null)
    }

    /** Diagnóstico (solo en pantallas con anuncio). Primero los posibles botones de cerrar. */
    private fun diagnostico(pkg: String, nodos: List<AccessibilityNodeInfo>, anuncioFuerte: Boolean, titulo: String) {
        val ahora = SystemClock.elapsedRealtime()
        if (ahora - ultimoDiagnostico < 4000) return

        val pantalla = tamanoPantalla()
        val importantes = mutableListOf<String>()
        val resto = mutableListOf<String>()
        for (n in nodos) {
            if (!n.isVisibleToUser) continue
            val txt = n.text?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val desc = n.contentDescription?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val id = idCorto(n)
            val clase = n.className?.toString()?.substringAfterLast('.') ?: ""
            val r = Rect()
            n.getBoundsInScreen(r)
            val clic = if (n.isClickable) " [clic]" else ""
            val linea = " · t='${txt.take(30)}' d='${desc.take(30)}' id=$id ($clase) @${r.left},${r.top}$clic"
            val esImportante = regexIdCerrar.containsMatchIn(id) ||
                    textos(n).any { it in cerrar || it in simbolosX || it in omitirCortos || it in omitirSeguros } ||
                    ((n.isClickable || n.isFocusable) && ladoEsquina(n, pantalla) != 0)
            if (esImportante) importantes.add("★$linea")
            else if (txt.isNotEmpty() || desc.isNotEmpty() || id.isNotEmpty() || n.isClickable) resto.add(linea)
        }
        val lineas = importantes.take(40) + resto.take(60)

        val huella = lineas.hashCode()
        if (huella == ultimaHuellaDiagnostico) return
        ultimaHuellaDiagnostico = huella
        ultimoDiagnostico = ahora

        AdLog.agregar(
            this,
            "══ $titulo en $pkg (fuerte=${if (anuncioFuerte) "SÍ" else "no"}) " +
                    "pantalla=${actividadActual.substringAfterLast('.')} ══\n" +
                    " (nodos totales: ${nodos.size})\n" +
                    (if (importantes.isEmpty()) " (no encontré botón de cerrar)\n" else "") +
                    lineas.joinToString("\n")
        )
    }
}
