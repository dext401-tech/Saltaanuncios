package com.mc.saltaanuncios

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var txtEstado: TextView
    private lateinit var txtRegistro: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnDiag: Button
    private lateinit var btnOscurecer: Button
    private lateinit var btnSilenciar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtEstado = findViewById(R.id.txtEstado)
        txtRegistro = findViewById(R.id.txtRegistro)
        scroll = findViewById(R.id.scrollRegistro)
        btnDiag = findViewById(R.id.btnDiagnostico)
        btnOscurecer = findViewById(R.id.btnOscurecer)
        btnSilenciar = findViewById(R.id.btnSilenciar)

        btnOscurecer.setOnClickListener {
            Prefs.setOscurecer(this, !Prefs.oscurecer(this))
            actualizar()
        }
        btnSilenciar.setOnClickListener {
            Prefs.setSilenciar(this, !Prefs.silenciar(this))
            actualizar()
        }

        findViewById<Button>(R.id.btnAccesibilidad).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Ábrelo en Ajustes > Preferencias del dispositivo > Accesibilidad",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        btnDiag.setOnClickListener {
            Prefs.setDiagnostico(this, !Prefs.diagnostico(this))
            actualizar()
        }

        findViewById<Button>(R.id.btnActualizar).setOnClickListener { actualizar() }

        findViewById<Button>(R.id.btnBorrar).setOnClickListener {
            AdLog.borrar(this)
            actualizar()
        }

        // Que el control empiece en el primer botón
        findViewById<Button>(R.id.btnAccesibilidad).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        actualizar()
    }

    private fun actualizar() {
        txtEstado.text = if (servicioActivo())
            "✅ Servicio ACTIVO: ya está saltando anuncios"
        else
            "❌ Servicio APAGADO: actívalo en Accesibilidad"

        btnDiag.text = if (Prefs.diagnostico(this))
            "Diagnóstico: ENCENDIDO"
        else
            "Diagnóstico: APAGADO"

        btnOscurecer.text = if (Prefs.oscurecer(this)) "Oscurecer: SÍ" else "Oscurecer: NO"
        btnSilenciar.text = if (Prefs.silenciar(this)) "Silenciar: SÍ" else "Silenciar: NO"

        txtRegistro.text = AdLog.leer(this).ifBlank { "(Sin registros todavía)" }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun servicioActivo(): Boolean {
        val habilitados = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, SaltaAnunciosService::class.java)
        val nombres = setOf(cn.flattenToString(), cn.flattenToShortString())
        return habilitados.split(':').any { s -> nombres.any { it.equals(s, ignoreCase = true) } }
    }
}
