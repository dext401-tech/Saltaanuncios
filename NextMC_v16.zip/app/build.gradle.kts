plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mc.saltaanuncios"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mc.saltaanuncios"
        minSdk = 24
        targetSdk = 34
        versionCode = 17
        versionName = "16.0"
    }

    // Firma fija: así cada versión nueva se instala encima sin desinstalar
    signingConfigs {
        create("mc") {
            storeFile = file("../mc.keystore")
            storePassword = "saltaanuncios"
            keyAlias = "mc"
            keyPassword = "saltaanuncios"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("mc")
            // Adelgazar y optimizar el código (menos tamaño y RAM)
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Sin librerías extra: solo lo que trae Android (app ultra ligera)
}
