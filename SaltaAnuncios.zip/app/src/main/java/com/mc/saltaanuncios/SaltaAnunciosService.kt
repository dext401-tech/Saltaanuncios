package com.mc.saltaanuncios

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Servicio de accesibilidad que NO bloquea anuncios.
 * El anuncio se muestra normal; en cuanto la app ofrece "Omitir anuncio",
 * "Saltar", "Skip" o una X para cerrarlo, este servicio lo presiona por ti.
 */
class SaltaAnunciosService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var escaneoPendiente = false
    private var ultimoClic = 0L
    private var reintentos = 0
    private var ultimoDiagnostico = 0L
    private var ultimaHuellaDiagnostico = 0

    // Apps donde nunca hace nada: ajustes, launcher y esta misma app
    private val excluidos = setOf(
        "com.mc.saltaanuncios",
        "com.android.tv.settings",
        "com.android.settings",
        "com.android.systemui",
        "com.google.android.tvlauncher",
        "com.google.android.apps.tv.launcherx",
        "com.google.android.leanbacklauncher"
    )

    // Botones que SIEMPRE son de anuncio
    private val omitirSeguros = setOf(
        "omitir anuncio", "omitir anuncios", "omitir publicidad",
        "saltar anuncio", "saltar anuncios", "saltar publicidad",
        "skip ad", "skip ads", "skip advertisement"
    )

    // Botones cortos: solo cuentan si en pantalla hay señales de anuncio
    private val omitirCortos = setOf("omitir", "saltar", "skip", "omitir ahora", "skip now")

    // Botones de cerrar: solo si hay señales de anuncio
    private val cerrar = setOf(
        "cerrar anuncio", "cerrar publicidad", "close ad",
        "cerrar", "close", "dismiss", "descartar"
    )
    private val simbolosX = setOf("x", "×", "✕", "✖", "╳", "⨉", "ⓧ", "⊗")

    // Cosas que NO queremos saltar (intros, resúmenes, créditos)
    private val palabrasProhibidas = listOf(
        "intro", "recap", "resumen", "credits", "créditos", "creditos", "episodio", "episode"
    )

    private val regexAnuncio = Regex("""\b(anuncios?|publicidad|patrocinado|sponsored|advertisement|ads?)\b""")
    private val regexIdAnuncio = Regex("""(^|[/_.:])(ads?|advert[a-z]*)([_.]|$)""")
    private val regexDigito = Regex("""\d""")

    override fun onServiceConnected() {
        super.onServiceConnected()
        AdLog.agregar(this, "Servicio iniciado")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg in excluidos) return
        reintentos = 0
        programarEscaneo(150)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun programarEscaneo(retrasoMs: Long) {
        if (escaneoPendiente) return
        escaneoPendiente = true
        handler.postDelayed({
            escaneoPendiente = false
            try {
                escanear()
            } catch (e: Exception) {
                AdLog.agregar(this, "Error: ${e.message}")
            }
        }, retrasoMs)
    }

    private fun escanear() {
        val raices = obtenerRaices()
        if (raices.isEmpty()) return

        val nodos = mutableListOf<AccessibilityNodeInfo>()
        for (r in raices) recolectar(r, nodos, 0)
        if (nodos.isEmpty()) return

        val pkg = raices.first().packageName?.toString() ?: "?"
        val hayAnuncio = nodos.any { it.isVisibleToUser && esSenalDeAnuncio(it) }

        if (Prefs.diagnostico(this)) diagnostico(pkg, nodos, hayAnuncio)

        // Buscar el mejor botón (prioridad menor = mejor)
        var elegido: AccessibilityNodeInfo? = null
        var etiqueta = ""
        var mejor = Int.MAX_VALUE
        for (n in nodos) {
            if (!n.isVisibleToUser || !n.isEnabled) continue
            val p = prioridad(n, hayAnuncio) ?: continue
            if (p.first < mejor) {
                mejor = p.first
                elegido = n
                etiqueta = p.second
            }
        }

        val nodo = elegido
        if (nodo == null) {
            // Hay anuncio pero el botón todavía no sale (cuenta regresiva): revisar otra vez
            if (hayAnuncio && reintentos++ < 40) programarEscaneo(800)
            return
        }

        val ahora = SystemClock.elapsedRealtime()
        if (ahora - ultimoClic < 1500) {
            programarEscaneo(800)
            return
        }
        ultimoClic = ahora

        val ok = clic(nodo)
        AdLog.agregar(this, (if (ok) "✔ Clic en '" else "✘ Falló clic en '") + etiqueta + "'  [" + pkg + "]")

        // Por si viene otro anuncio seguido
        programarEscaneo(1200)
    }

    /** Ventanas de apps normales (no sistema, no excluidas). */
    private fun obtenerRaices(): List<AccessibilityNodeInfo> {
        val lista = mutableListOf<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                if ((r.packageName?.toString() ?: "") in excluidos) continue
                lista.add(r)
            }
        } catch (_: Exception) {
        }
        if (lista.isEmpty()) {
            val r = rootInActiveWindow
            if (r != null && (r.packageName?.toString() ?: "") !in excluidos) lista.add(r)
        }
        return lista
    }

    private fun recolectar(n: AccessibilityNodeInfo, salida: MutableList<AccessibilityNodeInfo>, profundidad: Int) {
        if (salida.size > 2500 || profundidad > 60) return
        salida.add(n)
        for (i in 0 until n.childCount) {
            val hijo = n.getChild(i) ?: continue
            recolectar(hijo, salida, profundidad + 1)
        }
    }

    private fun textos(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.text, n.contentDescription)
            .map { normalizar(it.toString()) }
            .filter { it.isNotEmpty() }

    private fun normalizar(s: String): String =
        s.lowercase().trim().trim('›', '>', '▶', '▸', '►', '⏭', '|', '»', ' ').trim()

    private fun idCorto(n: AccessibilityNodeInfo): String =
        n.viewIdResourceName?.lowercase()?.substringAfter(":id/") ?: ""

    private fun esSenalDeAnuncio(n: AccessibilityNodeInfo): Boolean {
        if (textos(n).any { regexAnuncio.containsMatchIn(it) }) return true
        val id = idCorto(n)
        return id.isNotEmpty() && regexIdAnuncio.containsMatchIn(id)
    }

    /** Regresa (prioridad, etiqueta) si el nodo es un botón para quitar el anuncio. */
    private fun prioridad(n: AccessibilityNodeInfo, hayAnuncio: Boolean): Pair<Int, String>? {
        val ts = textos(n)
        val id = idCorto(n)

        // "Omitir en 5" = todavía no se puede; y nunca saltar intros/resúmenes
        if (ts.any { regexDigito.containsMatchIn(it) }) return null
        if ((ts + id).any { t -> palabrasProhibidas.any { it in t } }) return null

        for (t in ts) {
            if (t in omitirSeguros || t.startsWith("omitir anuncio") || t.startsWith("skip ad")) return 1 to t
            if (hayAnuncio && t in omitirCortos) return 2 to t
            if (hayAnuncio && (t in cerrar || t in simbolosX)) return 3 to t
        }

        if (hayAnuncio && id.isNotEmpty()) {
            if ("skip" in id || "omitir" in id) return 2 to "id:$id"
            val esCerrar = "close" in id || "cerrar" in id || "dismiss" in id
            if (esCerrar && regexIdAnuncio.containsMatchIn(id)) return 3 to "id:$id"
        }
        return null
    }

    private fun clic(nodo: AccessibilityNodeInfo): Boolean {
        // 1) El botón o su contenedor clicable
        var actual: AccessibilityNodeInfo? = nodo
        var nivel = 0
        while (actual != null && nivel < 6) {
            if (actual.isClickable && actual.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            actual = actual.parent
            nivel++
        }
        // 2) Intentar clic directo aunque no diga que es clicable
        if (nodo.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

        // 3) Plan B: "tocar" el centro del botón
        val r = Rect()
        nodo.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesto = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesto, null, null)
    }

    /** Modo diagnóstico: guarda qué botones/textos ve en pantalla. */
    private fun diagnostico(pkg: String, nodos: List<AccessibilityNodeInfo>, hayAnuncio: Boolean) {
        val ahora = SystemClock.elapsedRealtime()
        if (ahora - ultimoDiagnostico < 4000) return

        val lineas = mutableListOf<String>()
        for (n in nodos) {
            if (!n.isVisibleToUser) continue
            val txt = n.text?.toString()?.trim().orEmpty()
            val desc = n.contentDescription?.toString()?.trim().orEmpty()
            val id = idCorto(n)
            if (txt.isEmpty() && desc.isEmpty() && id.isEmpty()) continue
            val clic = if (n.isClickable) " [clic]" else ""
            lineas.add("   · t='${txt.take(40)}' d='${desc.take(40)}' id=$id$clic")
            if (lineas.size >= 60) break
        }

        val huella = lineas.hashCode()
        if (huella == ultimaHuellaDiagnostico) return
        ultimaHuellaDiagnostico = huella
        ultimoDiagnostico = ahora

        AdLog.agregar(
            this,
            "── Pantalla de $pkg (anuncio=${if (hayAnuncio) "SÍ" else "no"}) ──\n" + lineas.joinToString("\n")
        )
    }
}
